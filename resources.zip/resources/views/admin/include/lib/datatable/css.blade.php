<!-- Data Tables Stylesheet -->
<link rel="stylesheet" href="{{ url('admin/plugins/datatables-bs4/css/dataTables.bootstrap4.css') }}">